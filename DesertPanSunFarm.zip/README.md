# DesertCatchAndRelease
First: Goto left side of the healing station at the desert here...https://gyazo.com/50812018813751ddf4c6a9a6357f1291
Second: Make sure to buy 50+ TemCards
Third: Get into a battle and use a temcard to make it the most recent item used
Fourth: You can stand anywhere at that point as long as youre in the same vertical line as the healing station spot in the Screenshot provided
 
